# Caisse MAMINAINA — projet Android (APK)

Ce dossier prépare votre fichier HTML `index.html` pour être intégré dans une application Android avec Capacitor.

## Ce qui est inclus
- `www/index.html` : votre application Caisse, intégrée telle quelle.
- `capacitor.config.json` et `package.json` : configuration du projet Android.
- `android-plugin/.../NetworkPrinterPlugin.java` : module natif d'impression TCP/ESC-POS pour une imprimante réseau (port 9100), correspondant à l'appel `NetworkPrinter.print()` déjà prévu dans votre HTML.

## Pré-requis
- Un ordinateur Windows, macOS ou Linux (la compilation APK ne se fait pas directement sur le téléphone).
- Node.js LTS, Android Studio et Android SDK.
- Une connexion Internet lors de la première installation des dépendances.

## Générer le projet Android
Ouvrez un terminal dans ce dossier et exécutez :

```bash
npm install
npx cap add android
```

Ensuite, copiez le fichier Java du module d'impression fourni dans le projet Android :
`android-plugin/src/main/java/com/maminaina/caisse/NetworkPrinterPlugin.java`
vers :
`android/app/src/main/java/com/maminaina/caisse/NetworkPrinterPlugin.java`

Dans `android/app/src/main/java/com/maminaina/caisse/MainActivity.java`, ajoutez l'import :
```java
import com.maminaina.caisse.NetworkPrinterPlugin;
```
Puis ajoutez cette ligne dans la classe `MainActivity`, avant `super.onCreate(savedInstanceState);` :
```java
registerPlugin(NetworkPrinterPlugin.class);
```

Vérifiez que le package de `MainActivity.java` est `com.maminaina.caisse`. Si Capacitor a généré un autre package, harmonisez le package et l'`appId` avec `mg.maminaina.caisse`.

## Autorisation réseau Android
Dans `android/app/src/main/AndroidManifest.xml`, ajoutez avant `<application>` :
```xml
<uses-permission android:name="android.permission.INTERNET" />
```

Pour les versions Android récentes, la connexion à l'imprimante doit être autorisée sur le réseau Wi-Fi local. Gardez le téléphone connecté au Wi-Fi direct émis par l'imprimante.

## Réglage imprimante
Dans l'application : Plus → Imprimante → Réseau.
- Adresse IP : `10.10.100.254` (valeur connue de votre configuration actuelle)
- Port TCP : `9100` (port ESC/POS courant ; à confirmer si l'imprimante utilise un autre port)
- Téléphone : connecté au Wi-Fi direct de l'imprimante Xprinter XP-80T.

Le module envoie les octets ESC/POS sur TCP. Il ne nécessite ni Bluetooth ni USB pour ce mode.

## Compiler l'APK
1. Synchronisez : `npx cap sync android`
2. Ouvrez Android Studio : `npx cap open android`
3. Attendez la synchronisation Gradle.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio affiche un lien vers l'APK généré (généralement `android/app/build/outputs/apk/debug/app-debug.apk`).

## Important
- Ce ZIP est le **projet source prêt à être finalisé et compilé**, pas un APK déjà compilé.
- Je n'ai pas pu tester physiquement la XP-80T depuis ce projet. L'impression dépend de l'adresse IP et du port réellement utilisés par l'imprimante.
- Les fonctions de vente, historique, stock et produits restent dans le HTML. Les données utilisent le stockage local du navigateur WebView : ne désinstallez pas l'application sans avoir exporté/sauvegardé vos données si l'application propose cette fonction.
- L'impression système (`window.print`) peut nécessiter une adaptation native séparée ; le module inclus vise l'impression directe en réseau.
