package com.maminaina.caisse;

import android.util.Log;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import org.json.JSONArray;

@CapacitorPlugin(name = "NetworkPrinter")
public class NetworkPrinterPlugin extends Plugin {
    @PluginMethod
    public void print(PluginCall call) {
        String host = call.getString("host");
        Integer port = call.getInt("port", 9100);
        JSONArray data = call.getArray("data");
        if (host == null || host.trim().isEmpty() || data == null) {
            call.reject("Adresse IP ou données d'impression manquantes");
            return;
        }
        getBridge().execute(() -> {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host.trim(), port), 5000);
                socket.setSoTimeout(5000);
                OutputStream out = socket.getOutputStream();
                byte[] bytes = new byte[data.length()];
                for (int i = 0; i < data.length(); i++) {
                    bytes[i] = (byte) (data.optInt(i, 0) & 0xFF);
                }
                out.write(bytes);
                out.flush();
                call.resolve();
            } catch (Exception e) {
                Log.e("NetworkPrinter", "Échec impression réseau", e);
                call.reject("Impression impossible : " + e.getMessage(), e);
            }
        });
    }
}
