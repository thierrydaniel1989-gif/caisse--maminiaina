CAISSE MAMINAINA — COMPILATION APK AVEC GITHUB ACTIONS

Ce projet contient votre application HTML et un workflow GitHub Actions qui compile automatiquement un APK Android.

CRÉER LE NOUVEAU DÉPÔT DEPUIS LE TÉLÉPHONE
1. Ouvrir https://github.com/new et se connecter.
2. Nom du dépôt : caisse-maminaina-android
3. Choisir Public ou Private (au choix).
4. Cocher Add a README file, puis Create repository.
5. Dans le dépôt, ouvrir Add file > Upload files.
6. Décompresser ce ZIP sur le téléphone, puis téléverser le CONTENU du dossier Caisse_APK_Android (y compris le dossier caché .github).
   Important : téléverser les fichiers et dossiers du projet, pas le ZIP lui-même. Le dossier .github/workflows doit être présent.
7. Valider avec Commit changes sur la branche main.

LANCER / RÉCUPÉRER L'APK
- Ouvrir l'onglet Actions du dépôt.
- Choisir « Build Caisse MAMINAINA APK ».
- Si nécessaire, appuyer sur Run workflow.
- Attendre que le workflow soit terminé avec une coche verte.
- Ouvrir l'exécution réussie, descendre à Artifacts et télécharger « Caisse-MAMINAINA-APK ».
- Décompresser l'archive téléchargée : elle contient app-debug.apk.

IMPRIMANTE
Le plugin utilise TCP/ESC-POS, par défaut port 9100. Réglage connu à vérifier dans l'application : IP 10.10.100.254. Le téléphone doit être connecté au Wi-Fi direct de la Xprinter XP-80T.

À SAVOIR
- GitHub compile le projet dans le cloud : aucun ordinateur n'est nécessaire.
- Le workflow fabrique un APK de test (debug), installable sur Android après autorisation d'installation depuis cette source.
- Le bon fonctionnement de l'impression doit être vérifié avec l'imprimante réelle.
