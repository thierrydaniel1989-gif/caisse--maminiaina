package com.maminaina.caisse;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.JSArray;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "NetworkPrinter")
public class NetworkPrinterPlugin extends Plugin {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private Socket openSocket(String host, int port) throws Exception {
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 8000);
        socket.setSoTimeout(8000);
        return socket;
    }

    @PluginMethod
    public void testConnection(PluginCall call) {
        String host = call.getString("host");
        Integer port = call.getInt("port", 9100);
        if (host == null || host.trim().isEmpty()) {
            call.reject("Adresse IP de l'imprimante manquante");
            return;
        }
        final String targetHost = host.trim();
        final int targetPort = (port == null ? 9100 : port);
        executor.execute(() -> {
            try (Socket socket = openSocket(targetHost, targetPort)) {
                call.resolve();
            } catch (Exception e) {
                call.reject("Connexion à l'imprimante impossible (" + targetHost + ":" + targetPort + ") : " + e.getMessage(), e);
            }
        });
    }

    @PluginMethod
    public void print(PluginCall call) {
        String host = call.getString("host");
        Integer port = call.getInt("port", 9100);
        JSArray data = call.getArray("data");
        if (host == null || host.trim().isEmpty() || data == null) {
            call.reject("Adresse IP ou données d'impression manquantes");
            return;
        }
        final String targetHost = host.trim();
        final int targetPort = (port == null ? 9100 : port);
        executor.execute(() -> {
            try (Socket socket = openSocket(targetHost, targetPort)) {
                OutputStream out = socket.getOutputStream();
                byte[] bytes = new byte[data.length()];
                for (int i = 0; i < data.length(); i++) {
                    bytes[i] = (byte) (data.optInt(i, 0) & 0xFF);
                }
                out.write(bytes);
                out.flush();
                call.resolve();
            } catch (Exception e) {
                call.reject("Impression réseau impossible (" + targetHost + ":" + targetPort + ") : " + e.getMessage(), e);
            }
        });
    }
}
