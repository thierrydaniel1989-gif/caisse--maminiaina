CAISSE MAMINAINA - VERSION CORRIGEE 1.1

Cette version ajoute les dépendances Capacitor Filesystem et Share pour exporter les sauvegardes JSON, les ventes CSV et partager les PDF depuis Android. Le plugin NetworkPrinter envoie les tickets ESC/POS par TCP/IP (port 9100 par défaut).

IMPORTANT : l'APK déjà installé ne se met pas à jour automatiquement. Après compilation, téléchargez le nouvel APK depuis GitHub Actions > Build Caisse MAMINAINA APK > Artifacts, puis installez-le. Faites une sauvegarde des données de caisse avant de remplacer l'application.

Dans le dépôt GitHub, les fichiers du projet doivent être à la racine : package.json, capacitor.config.json, www/, android-plugin/ et .github/workflows/build-apk.yml. Ne téléversez pas le dossier Caisse_APK_Android comme un dossier imbriqué.

Imprimante : choisissez Ethernet/Wi-Fi, IP 10.10.100.254, port 9100. Le téléphone doit être connecté au Wi-Fi direct de l'imprimante.


CORRECTIONS TECHNIQUES v1.2
- Le module NetworkPrinter est appelé par le même mécanisme Capacitor que les autres plugins.
- Le bouton de test vérifie maintenant réellement l'ouverture TCP vers l'imprimante (port 9100).
- L'impression envoie les octets ESC/POS directement à l'imprimante réseau.
- Pour le Wi-Fi direct Xprinter, connectez le Samsung au réseau Wi-Fi émis par l'imprimante, puis utilisez l'adresse IP de l'imprimante (souvent 10.10.100.254) et le port 9100.
- L'export JSON, CSV et le partage PDF utilisent Filesystem + Share dans l'APK Android, avec téléchargement navigateur en solution de secours.

COMPILATION
1. Décompresser le contenu de Caisse_APK_Android à la racine du dépôt GitHub.
2. Envoyer les fichiers sur la branche main.
3. Ouvrir Actions > Build Caisse MAMINAINA APK.
4. Télécharger l'Artifact Caisse-MAMINAINA-APK-v1.2, puis app-debug.apk.
5. Installer l'APK sur Android. Avant remplacement, exporter une sauvegarde JSON depuis l'ancienne version.
