CAISSE MAMINAINA - VERSION CORRIGEE 1.1

Cette version ajoute les dépendances Capacitor Filesystem et Share pour exporter les sauvegardes JSON, les ventes CSV et partager les PDF depuis Android. Le plugin NetworkPrinter envoie les tickets ESC/POS par TCP/IP (port 9100 par défaut).

IMPORTANT : l'APK déjà installé ne se met pas à jour automatiquement. Après compilation, téléchargez le nouvel APK depuis GitHub Actions > Build Caisse MAMINAINA APK > Artifacts, puis installez-le. Faites une sauvegarde des données de caisse avant de remplacer l'application.

Dans le dépôt GitHub, les fichiers du projet doivent être à la racine : package.json, capacitor.config.json, www/, android-plugin/ et .github/workflows/build-apk.yml. Ne téléversez pas le dossier Caisse_APK_Android comme un dossier imbriqué.

Imprimante : choisissez Ethernet/Wi-Fi, IP 10.10.100.254, port 9100. Le téléphone doit être connecté au Wi-Fi direct de l'imprimante.
