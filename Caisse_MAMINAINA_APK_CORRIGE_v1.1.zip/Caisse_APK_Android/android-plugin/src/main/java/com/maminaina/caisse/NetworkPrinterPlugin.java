package com.maminaina.caisse;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.getcapacitor.JSArray;

@CapacitorPlugin(name = "NetworkPrinter")
public class NetworkPrinterPlugin extends Plugin {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @PluginMethod
    public void print(PluginCall call) {
        String host = call.getString("host");
        Integer port = call.getInt("port", 9100);
        JSArray data = call.getArray("data");
        if (host == null || host.trim().isEmpty() || data == null) {
            call.reject("Adresse IP ou données d'impression manquantes");
            return;
        }
        final int targetPort = (port == null ? 9100 : port);
        executor.execute(() -> {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host.trim(), targetPort), 8000);
                socket.setSoTimeout(8000);
                OutputStream out = socket.getOutputStream();
                byte[] bytes = new byte[data.length()];
                for (int i = 0; i < data.length(); i++) bytes[i] = (byte)(data.optInt(i, 0) & 0xFF);
                out.write(bytes);
                out.flush();
                call.resolve();
            } catch (Exception e) {
                call.reject("Impression réseau impossible : " + e.getMessage(), e);
            }
        });
    }
}
